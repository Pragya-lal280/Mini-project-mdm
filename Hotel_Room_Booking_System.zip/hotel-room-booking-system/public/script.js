const $ = id => document.getElementById(id);
const today = new Date().toISOString().slice(0,10);
$('searchIn').min = today; $('searchOut').min = today; $('checkIn').min = today; $('checkOut').min = today;

async function api(url, options={}) { const res = await fetch(url, {headers:{'Content-Type':'application/json'}, ...options}); const data = await res.json(); if(!res.ok) throw new Error(data.error || 'Something went wrong'); return data; }
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3000)}
function money(n){return '₹'+Number(n).toLocaleString('en-IN')}
function prettyDate(s){return new Date(s+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}

async function loadStats(){const s=await api('/api/stats');$('roomCount').textContent=s.rooms;$('bookingCount').textContent=s.bookings;$('upcomingCount').textContent=s.upcoming}
async function loadRooms(params=''){
  const rooms=await api('/api/rooms'+params); renderRooms(rooms); populateBookingRooms(rooms);
}
function renderRooms(rooms){
  const grid=$('roomsGrid'); if(!rooms.length){grid.innerHTML='<div class="empty">No rooms match your search. Try another date or room type.</div>';return}
  grid.innerHTML=rooms.map(r=>{const status=r.live_status||r.status;const cls=status==='Booked'?'busy':status==='Maintenance'?'maintenance':'';return `<article class="room-card"><span class="badge ${cls.toLowerCase()}">${status}</span><div class="number">#${r.room_no}</div><div class="type">${r.type} Room</div><div class="price">${money(r.price)} <small>/ night</small></div><div class="card-actions">${status==='Available'?`<button class="tiny-btn" onclick="selectRoom(${r.id})">Book this room</button>`:''}<button class="tiny-btn" onclick="deleteRoom(${r.id})">Delete</button></div></article>`}).join('')
}
function populateBookingRooms(rooms){$('bookingRoom').innerHTML='<option value="">Select an available room</option>'+rooms.filter(r=>(r.live_status||r.status)==='Available').map(r=>`<option value="${r.id}">#${r.room_no} — ${r.type} — ${money(r.price)}/night</option>`).join('')}
function selectRoom(id){$('bookingRoom').value=id;location.hash='booking';$('guestName').focus()}
async function searchRooms(){const type=$('searchType').value,ci=$('searchIn').value,co=$('searchOut').value;if((ci&&!co)||(!ci&&co))return toast('Please choose both check-in and check-out dates.');if(ci&&co&&ci>=co)return toast('Check-out must be after check-in.');const q=new URLSearchParams();if(type)q.set('type',type);if(ci)q.set('checkIn',ci);if(co)q.set('checkOut',co);await loadRooms(q.toString()?'?'+q.toString():'')}

$('bookingForm').addEventListener('submit',async e=>{e.preventDefault();const msg=$('bookingMessage');msg.textContent='';try{await api('/api/bookings',{method:'POST',body:JSON.stringify({roomId:$('bookingRoom').value,guestName:$('guestName').value,checkIn:$('checkIn').value,checkOut:$('checkOut').value})});e.target.reset();$('checkIn').min=today;$('checkOut').min=today;toast('Reservation confirmed ✦');await Promise.all([loadStats(),loadRooms(),loadBookings()])}catch(err){msg.textContent=err.message;msg.style.color='#b13e68'}});
$('checkIn').addEventListener('change',()=>{$('checkOut').min=$('checkIn').value||today});
$('searchIn').addEventListener('change',()=>{$('searchOut').min=$('searchIn').value||today});

$('roomForm').addEventListener('submit',async e=>{e.preventDefault();const msg=$('roomMessage');try{await api('/api/rooms',{method:'POST',body:JSON.stringify({roomNo:$('roomNo').value,type:$('roomType').value,price:$('roomPrice').value,status:$('roomStatus').value})});e.target.reset();msg.textContent='Room added successfully.';msg.style.color='#43804c';toast('New room added ✦');await Promise.all([loadStats(),loadRooms()])}catch(err){msg.textContent=err.message;msg.style.color='#b13e68'}});
async function deleteRoom(id){if(!confirm('Delete this room?'))return;try{await api('/api/rooms/'+id,{method:'DELETE'});toast('Room deleted');await Promise.all([loadStats(),loadRooms()])}catch(e){toast(e.message)}}
async function loadBookings(){const rows=await api('/api/bookings');$('bookingTable').innerHTML=rows.length?rows.map(b=>`<tr><td><strong>${escapeHtml(b.guest_name)}</strong></td><td>#${b.room_no}</td><td>${b.type}</td><td>${prettyDate(b.check_in)}</td><td>${prettyDate(b.check_out)}</td><td><button class="tiny-btn" onclick="cancelBooking(${b.id})">Cancel</button></td></tr>`).join(''):'<tr><td colspan="6" class="empty">No reservations yet.</td></tr>'}
async function cancelBooking(id){if(!confirm('Cancel this reservation?'))return;try{await api('/api/bookings/'+id,{method:'DELETE'});toast('Reservation cancelled');await Promise.all([loadStats(),loadRooms(),loadBookings()])}catch(e){toast(e.message)}}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
(async function init(){try{await Promise.all([loadStats(),loadRooms(),loadBookings()])}catch(e){toast('Could not connect to server. Run npm install and npm start.')}})();
