# Gilded Rose Hotel — Hotel Room Booking System

A full-stack assessment project built with **HTML, CSS, JavaScript, Node.js, Express.js and SQLite**.

## Features
- Add new rooms
- List and search rooms by type/date
- Book a room for a guest
- Prevent overlapping/double bookings
- Cancel reservations
- Delete rooms when they have no active/upcoming booking
- SQLite persistent database (`hotel.db` is created automatically)
- REST APIs using GET, POST and DELETE
- Fetch/AJAX updates without page reload
- Responsive pink + gold luxury/girly interface
- Dashboard statistics

## Requirements
- Node.js 18+ recommended
- npm

## Run the project
1. Extract the ZIP.
2. Open a terminal inside the project folder.
3. Run:
   ```bash
   npm install
   ```
4. Start the server:
   ```bash
   npm start
   ```
5. Open **http://localhost:3000** in your browser.

## API endpoints
- `GET /api/rooms`
- `POST /api/rooms`
- `DELETE /api/rooms/:id`
- `GET /api/bookings`
- `POST /api/bookings`
- `DELETE /api/bookings/:id`
- `GET /api/stats`

## Database
SQLite is used for persistent storage. Two related tables are created automatically:
- `rooms`: room number, type, price and maintenance status
- `bookings`: guest, room reference, check-in and check-out dates

## Assessment demo flow
1. Show the dashboard and room list.
2. Add a new room.
3. Search rooms by type/date.
4. Book an available room.
5. Attempt to book the same room for overlapping dates to demonstrate validation.
6. Show the reservation in the table.
7. Cancel the reservation and show availability returning.

## Project structure
```text
hotel-room-booking-system/
├── public/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── server.js
├── package.json
└── README.md
```
