const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 3000;
const db = new sqlite3.Database(path.join(__dirname, 'hotel.db'));

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function all(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
}
function run(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function (err) {
    if (err) reject(err); else resolve({ id: this.lastID, changes: this.changes });
  }));
}
function validDate(value) { return /^\d{4}-\d{2}-\d{2}$/.test(value); }
function todayISO() { return new Date().toISOString().slice(0, 10); }

async function init() {
  await run(`CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_no TEXT UNIQUE NOT NULL,
    type TEXT NOT NULL,
    price REAL NOT NULL CHECK(price >= 0),
    status TEXT NOT NULL DEFAULT 'Available' CHECK(status IN ('Available','Maintenance'))
  )`);
  await run(`CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER NOT NULL,
    guest_name TEXT NOT NULL,
    check_in TEXT NOT NULL,
    check_out TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(room_id) REFERENCES rooms(id) ON DELETE CASCADE
  )`);
  const count = await get('SELECT COUNT(*) AS count FROM rooms');
  if (count.count === 0) {
    const samples = [
      ['101','Deluxe',4500,'Available'], ['102','Deluxe',4500,'Available'],
      ['201','Suite',7500,'Available'], ['202','Suite',8000,'Available'],
      ['301','Standard',2800,'Available'], ['302','Standard',3000,'Available']
    ];
    for (const r of samples) await run('INSERT INTO rooms(room_no,type,price,status) VALUES(?,?,?,?)', r);
  }
}

app.get('/api/rooms', async (req, res) => {
  try {
    const { type, checkIn, checkOut } = req.query;
    let sql = `SELECT r.*, CASE WHEN r.status='Maintenance' THEN 'Maintenance'
      WHEN ? IS NOT NULL AND ? IS NOT NULL AND EXISTS (
        SELECT 1 FROM bookings b WHERE b.room_id=r.id AND date(b.check_in) < date(?) AND date(b.check_out) > date(?)
      ) THEN 'Booked' ELSE 'Available' END AS live_status
      FROM rooms r`;
    const params = [checkIn || null, checkOut || null, checkOut || '', checkIn || ''];
    const conditions = [];
    if (type) { conditions.push('r.type = ?'); params.push(type); }
    if (checkIn && checkOut) { conditions.push(`NOT EXISTS (SELECT 1 FROM bookings b2 WHERE b2.room_id=r.id AND date(b2.check_in) < date(?) AND date(b2.check_out) > date(?))`); params.push(checkOut, checkIn); }
    if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
    sql += ' ORDER BY CAST(r.room_no AS INTEGER), r.room_no';
    res.json(await all(sql, params));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/rooms', async (req, res) => {
  try {
    const { roomNo, type, price, status = 'Available' } = req.body;
    if (!roomNo || !type || price === undefined || price === '' || Number(price) < 0) return res.status(400).json({ error: 'Enter a valid room number, type and price.' });
    if (!['Available','Maintenance'].includes(status)) return res.status(400).json({ error: 'Invalid room status.' });
    const result = await run('INSERT INTO rooms(room_no,type,price,status) VALUES(?,?,?,?)', [String(roomNo).trim(), type, Number(price), status]);
    res.status(201).json(await get('SELECT * FROM rooms WHERE id=?', [result.id]));
  } catch (e) { res.status(400).json({ error: e.message.includes('UNIQUE') ? 'That room number already exists.' : e.message }); }
});

app.delete('/api/rooms/:id', async (req, res) => {
  try {
    const room = await get('SELECT * FROM rooms WHERE id=?', [req.params.id]);
    if (!room) return res.status(404).json({ error: 'Room not found.' });
    const active = await get("SELECT COUNT(*) AS count FROM bookings WHERE room_id=? AND date(check_out) >= date(?)", [req.params.id, todayISO()]);
    if (active.count) return res.status(409).json({ error: 'Cannot delete a room with an active/upcoming booking.' });
    await run('DELETE FROM rooms WHERE id=?', [req.params.id]);
    res.json({ message: 'Room deleted.' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/bookings', async (req, res) => {
  try {
    const rows = await all(`SELECT b.*, r.room_no, r.type, r.price FROM bookings b JOIN rooms r ON r.id=b.room_id ORDER BY date(b.check_in) ASC, b.id DESC`);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/bookings', async (req, res) => {
  try {
    const { roomId, guestName, checkIn, checkOut } = req.body;
    if (!roomId || !guestName || !checkIn || !checkOut) return res.status(400).json({ error: 'All booking fields are required.' });
    if (!validDate(checkIn) || !validDate(checkOut) || checkIn >= checkOut) return res.status(400).json({ error: 'Check-out must be after check-in and dates must be valid.' });
    if (checkIn < todayISO()) return res.status(400).json({ error: 'Check-in cannot be in the past.' });
    const room = await get('SELECT * FROM rooms WHERE id=?', [roomId]);
    if (!room) return res.status(404).json({ error: 'Room not found.' });
    if (room.status === 'Maintenance') return res.status(409).json({ error: 'This room is under maintenance.' });
    const clash = await get(`SELECT b.id FROM bookings b WHERE b.room_id=? AND date(b.check_in) < date(?) AND date(b.check_out) > date(?) LIMIT 1`, [roomId, checkOut, checkIn]);
    if (clash) return res.status(409).json({ error: 'This room is already booked for the selected dates.' });
    const result = await run('INSERT INTO bookings(room_id,guest_name,check_in,check_out) VALUES(?,?,?,?)', [roomId, guestName.trim(), checkIn, checkOut]);
    res.status(201).json(await get(`SELECT b.*, r.room_no, r.type, r.price FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.id=?`, [result.id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/bookings/:id', async (req, res) => {
  try {
    const booking = await get('SELECT * FROM bookings WHERE id=?', [req.params.id]);
    if (!booking) return res.status(404).json({ error: 'Booking not found.' });
    await run('DELETE FROM bookings WHERE id=?', [req.params.id]);
    res.json({ message: 'Booking cancelled successfully.' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/stats', async (req, res) => {
  try {
    const rooms = await get('SELECT COUNT(*) AS count FROM rooms');
    const bookings = await get('SELECT COUNT(*) AS count FROM bookings');
    const upcoming = await get("SELECT COUNT(*) AS count FROM bookings WHERE date(check_out) >= date(?)", [todayISO()]);
    res.json({ rooms: rooms.count, bookings: bookings.count, upcoming: upcoming.count });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

init().then(() => app.listen(PORT, () => console.log(`Hotel Room Booking System running at http://localhost:${PORT}`)))
  .catch(err => { console.error(err); process.exit(1); });
